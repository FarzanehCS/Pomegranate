# Pomegranate

Pomegranate is an app that enables users to sreach for the news that they would like to read.


## Quick Start Guide

1.  On your commandline, go to pomegranate project directory:

    ~~~~
   cd pomegranate
    ~~~~

    Then,

    ~~~~
    npm  install
    ~~~~

    Then,

    ~~~~
    meteor run 
    ~~~~

2.  open Pomegranate on your browser on local host on http://localhost:3000


3.  To stop the Pomegranate app, hit CTRL + Z on your keyboard.

## Technologies used:

- Meteor.js, node.js, npm
- https://newsapi.org/s/us-news-api
- Google cloud


## More later..
