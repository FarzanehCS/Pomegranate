import { Template } from 'meteor/templating';
// import { Tasks } from '../api/tasks.js'; 
import "./newsMainPage.js"
import './body.html';
import { ReactiveDict } from 'meteor/reactive-dict';
import { Meteor } from 'meteor/meteor';


// what should be created as part of the body Template
Template.body.onCreated(function bodyOnCreated() {
  this.state = new ReactiveDict();
});


// the helpers attached to the body template
Template.body.helpers({
  // tasks: [
  //   { text: 'This is task 1' },
  //   { text: 'This is task 2' },
  //   { text: 'This is task 3' },
  // ],
  // helper 1
  tasks(){
    const instance = Template.instance();
   if (instance.state.get('hideCompleted')) {
     // If hide completed is checked, filter tasks
     return Tasks.find({ checked: { $ne: true } }, { sort: { createdAt: -1 } });
   }
    return Tasks.find({}, {sort:{createdAt: -1}});
  },
  // helper 2
  incompleteCount() {
    return Tasks.find({ checked: { $ne: true } }).count();
  },
});


// the events and event listeners attached to the body template
Template.body.events(
  {
    // event 1
    'submit .new-task'(event){
      event.preventDefault();
      const target = event.target;
      const txt = target.text.value;

      Meteor.call('tasks.insert', txt);


    //   Tasks.insert({
    //     text :txt,
    //     createdAt: new Date(),
    //     owner: Meteor.userId(),
    //   username: Meteor.user().username,
    //   });
      target.text.value = "";
    },
    // event 2
    'change .hide-completed input'(event, instance) {
        instance.state.set('hideCompleted', event.target.checked);
      },
  }
);


//
// Template.body.events({
//   'submit .new-task'(event) {
//     // Prevent default browser form submit
//     event.preventDefault();
//
//     // Get value from form element
//     const target = event.target;
//     const text = target.text.value;
//
//     // Insert a task into the collection
//     Tasks.insert({
//       text,
//       createdAt: new Date(), // current time
//     });
//
//     // Clear form
//     target.text.value = '';
//   },
// });
