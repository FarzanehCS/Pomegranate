import { Meteor } from 'meteor/meteor';
import '../imports/api/articles.js';
import axios from 'axios';
// Imports the Google Cloud client library
const language = require('@google-cloud/language');

process.env.GOOGLE_APPLICATION_CREDENTIALS = '/Users/amir/desktop/google_cloud/gooogleAnalysis-ffbd59333e46.json';

Meteor.startup(() => {
  // code to run only on server at startup
});

Meteor.methods({
  'news.getNews': async (dataObj) => {
    const url = 'https://newsapi.org/v2/top-headlines';
    const params = {
      ...JSON.parse(dataObj),
      apiKey: 'e2309d6d17d849eeb4df66b15ab8ccee'
    };
    try {
      const { data : { articles = ''} = {}} = await axios.get(url, {
        params
      });
      if (dataObj.articleSentiment!= 'Both'){
        return await sentimentAnalysis(articles);
      }
      return articles;
    } catch (e) {
      console.log(e)
    }
  }
});

const sentimentAnalysis = async (articles) => {
  // Instantiates a client
  const client = new language.LanguageServiceClient();

  const articlesArray = await articles.map(async(article) => {
    
    const document = {
      content: article.title,
      type: 'HTML',
    };

    // Detects the sentiment of the article
    const [result] = await client.analyzeSentiment({ document: document });
    const sentiment = result.documentSentiment;
    return {
      ...article, sentiment: sentiment.score.toFixed(1)
    }
  });
  return await Promise.all(articlesArray);
}